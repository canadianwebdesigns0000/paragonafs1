<?php

// Message to be logged
$message = "This is a Error log message.";

// Write the message to the server's error log
error_log($message);


?>